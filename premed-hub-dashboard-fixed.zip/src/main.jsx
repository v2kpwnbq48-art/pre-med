import React from 'react'
import ReactDOM from 'react-dom/client'
import PremedHubDashboard from './PremedHubDashboard.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PremedHubDashboard />
  </React.StrictMode>
)
