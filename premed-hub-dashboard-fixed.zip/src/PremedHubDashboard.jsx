import React from 'react';

const LinkItem = ({ href, label }) => (
  <li style={{ marginBottom: '0.25rem' }}>
    <a href={href} target="_blank" rel="noreferrer">{label}</a>
  </li>
);

export default function PremedHubDashboard() {
  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem', maxWidth: 900, margin: '0 auto' }}>
      <h1 style={{ fontSize: '2rem', marginBottom: '0.25rem' }}>🩺 Premed Hub Dashboard</h1>
      <p style={{ color: '#555', marginBottom: '1.5rem' }}>All-in-one resource list for pre-med students (ready for Vercel + Notion).</p>

      <section style={{ marginBottom: '1.5rem' }}>
        <h2>Trackers</h2>
        <ul>
          <LinkItem href="https://www.notion.com/templates/pre-med-dashboard" label="Pre-Med Dashboard (Notion)" />
          <LinkItem href="https://www.notion.com/templates/pre-med-tracker-basic-edition" label="Pre-Med Tracker – Basic Edition" />
          <LinkItem href="https://www.notion.com/templates/pre-med-med-school" label="Pre-Med → Med School" />
          <LinkItem href="https://www.notion.com/templates/complete-pre-medical-personal-workspace" label="Complete Pre-Medical & Personal Workspace" />
          <LinkItem href="https://www.notion.com/templates/pre-medical-semester-dashboards" label="Semester Dashboard (Pre-Medical)" />
        </ul>
      </section>

      <section style={{ marginBottom: '1.5rem' }}>
        <h2>Core Resources</h2>
        <ul>
          <LinkItem href="https://students-residents.aamc.org/premed-resources/premed-resources" label="AAMC Premed Resources" />
          <LinkItem href="https://www.studentdoctor.net/" label="Student Doctor Network" />
          <LinkItem href="https://www.khanacademy.org/test-prep/mcat" label="Khan Academy MCAT" />
          <LinkItem href="https://blog.chartflow.io/posts/free-study-tools-for-pre-med-students" label="ChartFlow Free Study Tools" />
          <LinkItem href="https://www.oercommons.org/" label="OER Commons / Open Textbooks" />
          <LinkItem href="https://en.wikipedia.org/wiki/Free_Open_Access_Medical_Education" label="FOAMed" />
        </ul>
      </section>

      <section style={{ marginBottom: '1.5rem' }}>
        <h2>Worksheets</h2>
        <ul>
          <LinkItem href="https://students-residents.aamc.org/medical-school-admission-requirements/premed-worksheets-official-guide-medical-school-admissions" label="AAMC Premed Worksheets" />
          <LinkItem href="https://www.northwestern.edu/health-professions-advising/docs/hpa-fillable-planning-template-pre-med-no-gap-year.pdf" label="Northwestern Pre-Health Template" />
          <LinkItem href="https://offices.vassar.edu/pre-health-advising/for-students/worksheets-for-planning-and-preparation-for-a-healthcare-career/" label="Vassar Pre-Health Worksheets" />
          <LinkItem href="https://www.simmons.edu/sites/default/files/2024-07/pre-med-academic-plan-2024-2025.pdf" label="Simmons Pre-Med Academic Plan" />
          <LinkItem href="https://career.virginia.edu/sites/g/files/jsddwu971/files/2024-11/Pre-Health%20Planning%20Guide%20PDF%20for%20Website.pdf" label="UVA Pre-Health Planning Guide" />
        </ul>
      </section>

      <section style={{ marginBottom: '1.5rem' }}>
        <h2>Virtual Shadowing</h2>
        <ul>
          <LinkItem href="https://www.prehealthshadowing.com/" label="Pre-Health Shadowing" />
          <LinkItem href="https://shadowing.medschoolcoach.com/" label="MedSchoolCoach Virtual Shadowing" />
          <LinkItem href="https://virtualshadowing.com/" label="VirtualShadowing.com" />
          <LinkItem href="https://www.amwa-doc.org/virtual-shadowing-and-volunteering/" label="AMWA / HEAL Virtual Shadowing" />
          <LinkItem href="https://www.clinicalshadowing.com/" label="ClinicalShadowing.com" />
        </ul>
      </section>

      <section style={{ marginBottom: '1.5rem' }}>
        <h2>Workshops & Webinars</h2>
        <ul>
          <LinkItem href="https://students-residents.aamc.org/premed-webinars/premed-webinars" label="AAMC Premed Webinars" />
          <LinkItem href="https://www.kaptest.com/mcat/free/mcat-free-events" label="Kaplan Free MCAT Events" />
          <LinkItem href="https://lp.blueprintprep.com/mcat/free-resources/free-events" label="Blueprint MCAT Events" />
          <LinkItem href="https://bemoacademicconsulting.com/premed-research-webinar-registration-resource" label="BeMo Premed Research Webinar" />
          <LinkItem href="https://www.ama-assn.org/education/changemeded-initiative/medical-education-webinars" label="AMA ChangeMedEd Webinars" />
        </ul>
      </section>

      <section>
        <h2>Chicago / Loyola</h2>
        <ul>
          <LinkItem href="https://www.luc.edu/career/exploration/careercommunities/pre-medicinecareercommunity/" label="LUC Pre-Medicine Career Community" />
          <LinkItem href="https://luc.campuslabs.com/engage/organization/pre-health" label="Loyola Pre-Health Society" />
          <LinkItem href="https://www.luriechildrens.org/en/serving-the-community/magoon-institute-for-healthy-communities/MWDProgram/our-programs/" label="Lurie Children’s Hospital MWD" />
          <LinkItem href="https://caipper.uic.edu/for-students/2024-ipe-shadowing-program/" label="UIC Interprofessional Shadowing" />
          <LinkItem href="https://www.cmsdocs.org/events" label="Chicago Medical Society Events" />
        </ul>
      </section>
    </div>
  );
}
