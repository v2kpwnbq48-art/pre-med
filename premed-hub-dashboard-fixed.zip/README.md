# Premed Hub Dashboard (Vercel + Vite)

## Quick Deploy
1. Go to https://vercel.com/new → **Upload Project** and select this folder as a ZIP.
2. Framework: **Vite** (auto), Build: `npm run build`, Output: `dist`.
3. After deploy, embed your URL in Notion with `/embed`.

## Local Dev
```bash
npm install
npm run dev
```
