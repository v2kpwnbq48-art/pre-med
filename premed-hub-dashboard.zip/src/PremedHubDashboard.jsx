import React from 'react';

export default function PremedHubDashboard() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>🩺 Premed Hub Dashboard</h1>
      <p>All-in-one resource list for pre-med students.</p>
      <ul>
        <li><a href='https://students-residents.aamc.org/premed-resources/premed-resources' target='_blank'>AAMC Premed Resources</a></li>
        <li><a href='https://www.studentdoctor.net/' target='_blank'>Student Doctor Network</a></li>
        <li><a href='https://www.prehealthshadowing.com/' target='_blank'>Pre-Health Shadowing</a></li>
        <li><a href='https://luc.campuslabs.com/engage/organization/pre-health' target='_blank'>Loyola Pre-Health Society</a></li>
      </ul>
    </div>
  );
}
